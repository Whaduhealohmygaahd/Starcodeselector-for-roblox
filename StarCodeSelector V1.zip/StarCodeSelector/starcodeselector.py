import tkinter
from tkinter import *
from random import randrange
import pickle
import time
import pprint, pickle
Starcodes = ["DV","NOODLES","OLIX","LCLC","LAUGH","SCRIPTED","REALKREEK"]
Colors = ["blue","green","red","pink","purple","black","yellow","#999999"]

pkl_file = open('data.pkl', 'rb')

data1 = pickle.load(pkl_file)
pprint.pprint(data1)

selectedcolor = data1

pkl_file.close()


window = tkinter.Tk()
window.geometry("{0}x{1}+0+0".format(window.winfo_screenwidth(), window.winfo_screenheight()))
window.title("Starcode Selector")
window.config(background=Colors[selectedcolor - 1])
def CLOSEPROGRAM():
    pickle_data()
    window.destroy()
    exit("Done!")

def changewindowcolor():
    global selectedcolor
    if selectedcolor < 8:
        ACTUALSELECTEDCOLOR = Colors[selectedcolor]
        window.config(background=ACTUALSELECTEDCOLOR)
        selectedcolor = selectedcolor + 1
    if selectedcolor > 7:
        selectedcolor = 0

def Generate():
    global CODE
    number = randrange(0,7)
    time.sleep(0.001)
    CODE = "Use Starcode " + Starcodes[number] + " when buying robux!"
    T.insert(tkinter.END, CODE)
    number = ""

def opensettings():
    #popup
    global settings
    settings = Tk()
    settings.title("Settings")
    settings.geometry("500x700")
    settings.iconbitmap("icons/settings.ico")
    #color change
    global modifycolor
    modifycolor = tkinter.Button(settings,text="Color")
    modifycolor.config(command=changewindowcolor)
    modifycolor.place(x=10, y=10)
    settings.mainloop()

    #save data
def pickle_data():
    filename = 'data.pkl'
    outfile = open(filename, 'wb')
    pickle.dump(selectedcolor,outfile)
    outfile.close()



#Exit button
exitprogram = tkinter.Button(window,text="X")
window.attributes("-fullscreen", True)
exitprogram.config(font=("Ink Free",10,"bold"))
exitprogram.config(bg="#Ffffff")
exitprogram.config(fg="#000000")
exitprogram.config(activebackground="#808080")
exitprogram.config(command=CLOSEPROGRAM)
exitprogram.config(activeforeground="#000000")
exitprogram.config(border=False)
exitprogram.config(width=2,height=2)
exitprogram.place(x=1898,y=0)
#Generate Button
GenerateButton = tkinter.Button(window,text="Generate")
GenerateButton.config(font=("Ink Free",10,"bold"))
GenerateButton.config(height=3,width=26)
GenerateButton.config(command=Generate)
GenerateButton.place(x=860,y=540)
#starcode
T = tkinter.Text(window, height = 5, width = 52)
l = tkinter.Label(window, text = "Starcode")
l.config(font =("Courier", 14))
l.pack()
T.pack()
#enter settings
photo = tkinter.PhotoImage(file="images/settings.png")
entersettings = tkinter.Button(window, image=photo,width=100, height=100)
entersettings.config(command=opensettings)
entersettings.place(x=0, y=0)
window.mainloop()

T.insert(tkinter.END, CODE)