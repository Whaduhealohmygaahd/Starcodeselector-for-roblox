|-----------------------------------------------------------------------------------------------------------------|
|DO NOT DELETE "data.pkl" IF DELETED RUN "regeneratepickle.py" IN VSC ("Visual Studio Code")			  |
|-----------------------------------------------------------------------------------------------------------------|
|IF AN IMPORTANT FILE HAS BEEN DELETED ("build, dist,starcodeselector.spec or starcodeselector.exe") THEN OPEN VSC|
|AND RUN COMMAND (pyinstaller --onefile --clean pyinstaller.py) IN THE TERMINAL. 				  |
|(video coming soon in download files)										  |
|-----------------------------------------------------------------------------------------------------------------|
|IF IMPORTANT FILES ARE CORRUPTED OR DELETED ("images, icons") THEN RE-DOWNLOAD THE FILES			  |
|-----------------------------------------------------------------------------------------------------------------|


Created by Aaron Hugh Mac Dowwel da Costa Innecco

This application is subject to copyright and trademark laws.
Showcasing on social media is allowed but putting on other websites to download is strictly prohibited™
